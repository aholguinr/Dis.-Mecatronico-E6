
EN   Your CAD data on 23.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 5340825 CMMT-AS-C4-3A-EP-S1 
    
    AIS2021, 5340825 CMMT-AS-C4-3A-EP-S1, 4021832 2GD-1RR7_62-CLP-CBL.ipt
    AIS2021, 5340825 CMMT-AS-C4-3A-EP-S1, 4978445 CMMT-AS-3A---(clamp).ipt
    AIS2021, 5340825 CMMT-AS-C4-3A-EP-S1, 5340825 CMMT-AS-C4-3A-EP-S1---(h).ipt
    AIS2021, 5340825 CMMT-AS-C4-3A-EP-S1, 5340825 CMMT-AS-C4-3A-EP-S1.iam
    AIS2021, 5340825 CMMT-AS-C4-3A-EP-S1, 5395254 CAFC-C6-C.ipt
    AIS2021, 5340825 CMMT-AS-C4-3A-EP-S1, ISO 14580 M4x16.ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
