
EN   Your CAD data on 23.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 5054513 NEKM-C6-C16-D 
    
    AIS2021, 5054513 NEKM-C6-C16-D, 3943083 12GD-1RR3,5-CLP-CBL.ipt
    AIS2021, 5054513 NEKM-C6-C16-D, 3943133 4GD-1RR5,08-CLP-CBL.ipt
    AIS2021, 5054513 NEKM-C6-C16-D, 3943136 6GD-2RR3,5-CLP-CBL.ipt
    AIS2021, 5054513 NEKM-C6-C16-D, 3943299 10GD-2RR3,5-CLP-CBL.ipt
    AIS2021, 5054513 NEKM-C6-C16-D, 4280684 14RD-1RR5_08-CLP-CBL.ipt
    AIS2021, 5054513 NEKM-C6-C16-D, 4377733 12GD-1RR3,5-CLP-CBL.ipt
    AIS2021, 5054513 NEKM-C6-C16-D, 5054513 NEKM-C6-C16-D.iam
    AIS2021, 5054513 NEKM-C6-C16-D, 8084904 CAFC-C6-T.ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
