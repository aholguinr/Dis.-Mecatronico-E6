
EN   Your CAD data on 06.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 1725850 EAGF-V2-KF-100-100 
    
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 1558863 EAGF-V2-KF-100---(J).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 1559396 EAGF-V2-KF-100---(R).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 1559400 EAGF-V2-KF-80_100---(GS).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 1725850 EAGF-V2-KF-100-100---(0).iam
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 242770 EAGF 25x35x40---(B).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 247465 FEN-80-SD---(SD).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 2608532 EAGF-100-100-KF---(FST).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), 2608532 EAGF-V2-KF-100---(F).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), DIN-6912 - M12x25(F).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), DIN-912 - M10x50(F).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), DIN-912 - M12x25(F).ipt
    AIS2021, 1725850 EAGF-V2-KF-100-100---(0), DIN-913 - M18x20.ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
