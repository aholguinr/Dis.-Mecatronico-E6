
EN   Your CAD data on 06.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 2803622 EAMM-U-145-D100-120G-188-S1 
    
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, 1451339 M10-NBR-10x16_9x1_5.ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, 1464690 EAMM-U-145-D100-___-348S---(OT).ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, 1465008 EAMM-U-145-D100-140A-348S---(UT).ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, 2683767 EAMF-U-140A-120G-S1---(ADAX).ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, 2803622 EAMM-U-145-D100-120G-188-S1.iam
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, 706368 GPN.ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, DIN 557 - M10.ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, DIN-6912 - M10x20(F).ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, DIN-912 - M10x20(F).ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, DIN-912 - M10x55(F).ipt
    AIS2021, 2803622 EAMM-U-145-D100-120G-188-S1, DIN-912 - M8x50(F).ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
