
EN   Your CAD data on 06.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 574118 ESBF-BS-100-100-20P 
    
    AIS2021, 574118 ESBF-BS-100-100-20P---(0), 1515746 GUA M28x1_5.ipt
    AIS2021, 574118 ESBF-BS-100-100-20P---(0), 574118 ESBF-BS-100-100-20P---(0).iam
    AIS2021, 574118 ESBF-BS-100-100-20P---(0), DIN-439-B - M20x1_5(F).ipt
    AIS2021, 574118 ESBF-BS-100-100-20P---(0), ESBF-BS-100-100---(ZR_-_-).ipt
    AIS2021, 574118 ESBF-BS-100-100-20P---(0), ESBF-BS-100-100-20P---(KS_0).ipt
    AIS2021, 574118 ESBF-BS-100-100-20P---(0), ESBF-BS-100-ESBF-BS-100---(KSA).ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
