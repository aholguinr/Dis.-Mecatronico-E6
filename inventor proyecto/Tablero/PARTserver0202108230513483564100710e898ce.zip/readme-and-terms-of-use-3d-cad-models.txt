
EN   Your CAD data on 23.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 5119205 NEKM-C6-C45-P3-S 
    
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 3943083 12GD-1RR3,5-CLP-CBL.ipt
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 3943136 6GD-2RR3,5-CLP-CBL.ipt
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 3943299 10GD-2RR3,5-CLP-CBL.ipt
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 4377733 12GD-1RR3,5-CLP-CBL.ipt
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 5065608 2GD-1RR5,08-CLP-CBL.ipt
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 5065752 4GD-1RR7_62-CLP-CBL.ipt
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 5065802 6GD-1RR7_62-CLP-CBL.ipt
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 5119205 NEKM-C6-C45-P3-S.iam
    AIS2021, 5119205 NEKM-C6-C45-P3-S, 8084904 CAFC-C6-T.ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
