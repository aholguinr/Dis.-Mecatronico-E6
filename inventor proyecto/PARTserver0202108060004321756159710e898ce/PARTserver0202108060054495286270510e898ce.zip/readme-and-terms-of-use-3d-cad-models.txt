
EN   Your CAD data on 06.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 552198 EMGA-120-P-G3-SAS-140 
    
    AIS2021, 552198 EMGA-120-P-G3-SAS-140, 552198 EMGA-120-P-G3-SAS-140---(P).ipt
    AIS2021, 552198 EMGA-120-P-G3-SAS-140, 552198 EMGA-120-P-G3-SAS-140.iam
    AIS2021, 552198 EMGA-120-P-G3-SAS-140, DIN-912 - M10x35(F).ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
