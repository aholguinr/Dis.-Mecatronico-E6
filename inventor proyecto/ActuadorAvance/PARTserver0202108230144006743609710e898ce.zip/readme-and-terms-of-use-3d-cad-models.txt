
EN   Your CAD data on 23.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 174370 HNC-40 
    
    AIS2021, 174370 HNC-40_(50), 174370 HNC-40---(F).ipt
    AIS2021, 174370 HNC-40_(50), 174370 HNC-40_(50).iam
    AIS2021, 174370 HNC-40_(50), DIN-912 - M6x18(F).ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
