
EN   Your CAD data on 23.08.2021 from Festo:

    Dear customer,
    
    attached please find the following file of our 2D/3D-CAD download portal powered by CADENAS:

	identification number: 2617488 EAMM-U-70-D40-60P-96 
    
    AIS2021, 2617488 EAMM-U-70-D40-60P-96, 2607475 EAMM-U-70-D40-60P-96---(UT).ipt
    AIS2021, 2617488 EAMM-U-70-D40-60P-96, 2610112 EAMM-U-70-D40-___-173---(OT).ipt
    AIS2021, 2617488 EAMM-U-70-D40-60P-96, 2617488 EAMM-U-70-D40-60P-96.iam
    AIS2021, 2617488 EAMM-U-70-D40-60P-96, DIN 557 - M4.ipt
    AIS2021, 2617488 EAMM-U-70-D40-60P-96, DIN-6912 - M6x18(F).ipt
    AIS2021, 2617488 EAMM-U-70-D40-60P-96, DIN-912 - M4x16(F).ipt
    AIS2021, 2617488 EAMM-U-70-D40-60P-96, DIN-912 - M5x35(F).ipt
    
    Please also check terms of use at:
    https://www.cadenas.de/terms-of-use-3d-cad-models
    
    Best regards

    Festo SE & Co. KG
    CAD Service
    design_tool@festo.com
    
